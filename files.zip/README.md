# LetItEdit: setup guide

## Files to upload to GitHub (keep the same names)
Root: `index.html`, `tools.html`, `freelance.html`, `order.html`, `faq.html`, `how-to-use.html`, `terms.html`, `privacy.html`, `site.css`, `site.js`, `config.js`, `tools.js`, `order.js`, `robots.txt`, `sitemap.xml`, `_headers`
Folder `functions/`: `send-email.js`, `approve-order.js` (replace the old ones)
Not uploaded to the website, only used once: `supabase-setup.sql`

## 1. Supabase (once)
1. Open your Supabase project, then SQL Editor, New query.
2. Paste everything from `supabase-setup.sql` and press Run. It creates a new `editing_orders` table and a private `uploads` bucket. Your old table is not touched.
3. Orders and uploaded files appear in Table Editor and Storage.

## 2. Email notification (Resend)
1. Create a free account at resend.com and create an API key.
2. Until you verify your own domain in Resend, emails can only go to the email address you signed up with. Use that address as `OWNER_EMAIL`.
3. Later, verify letitedit.com in Resend and set `FROM_EMAIL` (for example `LetItEdit Orders <orders@letitedit.com>`).

## 3. Cloudflare Pages
1. Cloudflare dashboard, Workers and Pages, Create, Pages, Connect to Git, choose the repo. Build command: none. Output directory: `/`.
2. Settings, Variables and Secrets, add these (mark the keys as Secret):
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SERVICE_KEY` = the service_role key (Supabase, Project Settings, API). Never put it in GitHub.
   - `APPROVE_SECRET` = any long random text (30+ characters)
   - `RESEND_API_KEY` = your Resend key
   - `OWNER_EMAIL` = the email that receives orders
   - `FROM_EMAIL` = optional
3. Custom domain: add letitedit.com under the Pages project. Redeploy after you add variables.
4. Tip: Cloudflare Email Routing can make `hello@letitedit.com` forward to your inbox. The site lists that address as its contact.

## 4. Test the whole order flow
1. Open /freelance, choose a service, continue, fill the form, tick the terms, press Proceed to payment.
2. Check that the pop-up shows the PayPal button and that the order email arrives.
3. Open the email link, press Approve payment. The order page should switch to upload within a few seconds.
4. Upload a file. Check it in Supabase Storage, folder named with the order id.
5. Turn off your internet and try a tool and an order. Both should show an offline message.

## Things to check
- Prices for services other than screenshot editing are my assumptions. Edit them in `config.js` and in the price lists on `freelance.html`.
- Orders are approved only when you press the button in the email. Check PayPal first.
- Read `terms.html` and `privacy.html` and make sure every statement is true for you. Have a lawyer review the terms.
- The anon key in `config.js` is public by design. The security comes from the SQL policies.

## If order emails do not arrive
1. In Cloudflare Pages, Settings, Variables and Secrets, check that these exist for **Production** (not only Preview): `RESEND_API_KEY`, `OWNER_EMAIL`, `APPROVE_SECRET`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, and `FROM_EMAIL`. Redeploy after changing them.
2. Once your domain is verified in Resend (status **Verified**, not Pending), set `FROM_EMAIL` to an address on that domain, for example `LetItEdit Orders <orders@letitedit.com>`. Without it, the site sends from onboarding@resend.dev, which only reaches your Resend sign-up email.
3. Open `https://letitedit.com/send-email` in your browser. It shows which settings are present (true or false).
4. Open `https://letitedit.com/send-email?test=YOUR_APPROVE_SECRET` to send a test email. The answer shows exactly what Resend replied.
5. In the Resend dashboard, open Emails (logs). If nothing is listed, the request never reached Resend. If it is listed, read the status. Also check your spam folder.

## New files in this update
`tools2.js` (image enhance, file merger, file converter, help buttons). Upload it with `tools.html`, `tools.js`, `index.html`, `site.css`, `site.js` and `functions/send-email.js`, `functions/approve-order.js`.
